/*************************************************
Copyright
File name: ScriptEngine.cpp
Author: �ų���
Version: 
Date: 2012/11/24
*************************************************/
#include "StdAfx.h"
#include "ScriptEngine.h"

CScriptEngine::CScriptEngine(void)
{
}

CScriptEngine::~CScriptEngine(void)
{
}