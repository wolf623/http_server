//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by WebServer.rc
//
#define IDC_MYICON                      2
#define IDD_WEBSERVER_DIALOG            102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDD_MAINDLG                     103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_WEBSERVER                   107
#define IDI_SMALL                       108
#define IDC_WEBSERVER                   109
#define IDR_MAINFRAME                   128
#define ID_SWITCH                       1000
#define IDC_LIST_REPORT                 1001
#define ID_CONFIG                       1002
#define IDC_CHECK_ONLIST                1003
#define IDC_CHECK_LOG                   1004
#define IDC_CHECK_IP                    1005
#define IDC_CHECK_URL                   1006
#define IDC_CHECK_STATUS                1007
#define IDC_CHECK_BYTES                 1008
#define IDC_CHECK_DATE                  1009
#define IDC_EDIT_ROOTPATH               1010
#define ID_SCANPATH                     1011
#define IDC_CHECK_RECORDCONN            1012
#define IDC_CHECK_SIMPLEC               1013
#define IDC_DIVIDE                      1014
#define IDC_CONNECTNUM                  1015
#define IDC_CHECK_SIMPLEC2              1016
#define IDC_CHECK_STATICHTML            1016
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
