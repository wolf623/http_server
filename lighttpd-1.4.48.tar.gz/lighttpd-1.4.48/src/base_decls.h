#ifndef INCLUDED_BASE_DECLS_H
#define INCLUDED_BASE_DECLS_H

#include "first.h"

#include <sys/types.h>

struct server;
typedef struct server server;

struct connection;
typedef struct connection connection;

union sock_addr;
typedef union sock_addr sock_addr;


#endif
